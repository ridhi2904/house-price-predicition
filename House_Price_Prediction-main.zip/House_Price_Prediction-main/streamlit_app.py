import streamlit as st
from predict import predict_price

st.title("🏠 House Price Prediction System")
st.subheader("Model Comparison: Decision Tree vs Random Forest")

# Select model
model_choice = st.selectbox(
    "Choose a Model:",
    ["Decision Tree", "Random Forest"]
)

st.write("### Enter House Features")

# Example Inputs (change according to your dataset)
feature1 = st.number_input("Feature 1", value=1000)
feature2 = st.number_input("Feature 2", value=3)
feature3 = st.number_input("Feature 3", value=2)
feature4 = st.number_input("Feature 4", value=1)

features = [feature1, feature2, feature3, feature4]

if st.button("Predict Price"):
    price = predict_price(model_choice, features)
    st.success(f"Predicted House Price: ₹{price:,.2f}")
