import pandas as pd
from sklearn.model_selection import train_test_split

def load_data():
    """
    Loads the dataset and performs train-test split.
    Assumes dataset is stored as 'data.csv' inside project.
    """
    df = pd.read_csv("data.csv")

    # Target variable
    y = df["price"]

    # Feature columns
    X = df.drop("price", axis=1)

    # Train-test split
    return train_test_split(X, y, test_size=0.2, random_state=42)
