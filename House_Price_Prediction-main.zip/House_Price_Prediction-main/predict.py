import joblib
import numpy as np

def load_model(model_name):
    if model_name == "Decision Tree":
        return joblib.load("models/decision_tree.joblib")
    else:
        return joblib.load("models/random_forest.joblib")

def predict_price(model_name, features):
    model = load_model(model_name)
    features_arr = np.array(features).reshape(1, -1)
    return model.predict(features_arr)[0]
